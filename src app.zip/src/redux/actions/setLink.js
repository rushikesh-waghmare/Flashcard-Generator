export const addGroupId = (id) => {
    return {
        type: 'addGroupId',
        payload: id
    }
}
export const addCardId = (id) => {
    return {
        type: 'addCardId',
        payload: id
    }
}