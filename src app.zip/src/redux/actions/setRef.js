
export const addRef = (val) => {
    return {
        type: 'addRef',
        payload: val
    }
}